Documentation in ReST format. You can read them "as is", or you can
process it first with Python "docutils" package.

The root document is "contents.rst".

The "make" process is taken directly from the Python 2.6 documentation.
If you do "make html", you can find the generated HTML in directory
"build/html/". You don't need to to this if you only want to read
the documentation.

Files "Makefile", "conf.py" and directory "tools" are taken from Python
2.6 subversion, r61329.

